angular.module('tmht')
.controller('aboutCtrl', ['$scope','$location', function($scope, $location){


}]);