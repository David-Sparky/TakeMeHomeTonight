angular.module('tmht')
.controller('landingCtrl', ['$scope', '$http', '$window', function($scope, $http, $window){
	

}]);